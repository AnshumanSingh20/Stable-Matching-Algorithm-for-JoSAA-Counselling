package com.jeeseatallocation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeeseatallocationApplication {

    public static void main(String[] args) {
        SpringApplication.run(JeeseatallocationApplication.class, args);
    }
}
