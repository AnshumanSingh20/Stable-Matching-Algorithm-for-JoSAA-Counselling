package com.jeeseatallocation.enums;

public enum QuotaType {
    NONE,  // For IITs
    HS,    // Home State
    OS     // Other State
}
