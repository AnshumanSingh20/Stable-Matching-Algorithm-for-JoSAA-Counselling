package com.jeeseatallocation.enums;

public enum GenderType {
    GN,   // Gender-Neutral
    F     // Female-Only
}
