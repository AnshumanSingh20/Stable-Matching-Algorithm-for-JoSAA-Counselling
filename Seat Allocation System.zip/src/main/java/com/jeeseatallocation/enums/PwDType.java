package com.jeeseatallocation.enums;

public enum PwDType {
    NONE,
    PWD
}
