package com.jeeseatallocation.enums;

public enum CategoryType {
    OPEN, OBC, EWS, SC, ST
}
